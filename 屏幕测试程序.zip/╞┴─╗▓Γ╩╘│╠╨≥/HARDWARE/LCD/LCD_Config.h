
#define X_MAX_PIXEL	        160
#define Y_MAX_PIXEL	        80


