#ifndef __VFD_DRIVER_H
#define __VFD_DRIVER_H 			   
#include "sys.h"  


#define DI 		PBout(15)	// PD2	
#define LAT 	PBout(12)	// PD2	
#define BLK 	PBout(14)	// PD2	
#define CLK 	PBout(13)	// PD2	


void DispNum(uint8_t position , uint8_t value);


void setBufferedIntData(uint8_t page,uint32_t values,uint8_t endValue);
void setBufferedData(uint8_t page,uint8_t block,uint8_t values);
	
void clearBufferedData(uint8_t page,uint8_t block);
void bufferedDisp();

#endif