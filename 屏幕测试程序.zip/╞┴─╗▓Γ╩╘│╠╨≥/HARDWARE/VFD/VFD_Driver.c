
#include "sys.h"
#include "47m231t.h"
#include "VFD_Driver.h"
#include "delay.h"
#include "timer.h"
/**
���߶��壺
C6 SCL
C7 SDA
C8 RES
C9 DC
CS Ĭ�Ͻ�GND
BLK ����Ĭ�Ͽ��� ���Զ̽�GND�ر�

B0 18B20 ���
B1 18B20 �䶳

A8 �̵���

**/

 unsigned char a_buf[1][1];	//������Ļ�Ĵ�������Ϊ96�У�1ҳ
 uint8_t dispBuffer[10][5];	//������Ļ�Ĵ���������10ҳ��ÿҳ5�ֽ�

void SendByte(unsigned char Byte)
{

   unsigned char m,dat;
   dat = Byte;
   for(m=0;m<8;m++)
   {
   if(dat&0x80){DI = 1;}//��λ���� 
	 else{DI = 0;}
	 CLK = 0;
	 CLK = 1;
	 dat = dat<<1;
	}
}

void SkipSend(){
	unsigned char m;
	for(m=0;m<40;m++){
		CLK = 0;
		CLK = 1;
	}
}

void LAT_BLK_SEND(void)
{
	BLK = 1;
	LAT = 1;	
	LAT = 0;
	BLK = 0;
}
/*--------------------------------------
��������grid_send
����  : ��������96λ����
���� ��Display[]
����ֵ����
-------------------------------------*/

/*--------------------------------------
��������grid_send
����  : ����ɨ���ź�
���� ��t�� 0 --- 35 Ϊһ��ɨ������
����ֵ����
-------------------------------------*/

//void grid_send2(unsigned char t) //�²���դ�� 1-27G
//{
//   SendByte(grid2[t*4-4]);
//   SendByte(grid2[t*4-3]);
//   SendByte(grid2[t*4-2]);
//   SendByte(grid2[t*4-1]);
//			
//}
void gridSelect(unsigned char t)//�ϲ���դ�� 1-10G
{
   SendByte(grid[t][0]);
   SendByte(grid[t][1]);
}
void bufferedDisp(){ //ʵ����Ļˢ�£�ʹ�����û���
	static uint8_t i=0;
	if (i>=10) i=0;
	//if (i==6) i=7;	//����Grid 7 
	SkipSend() ;
	gridSelect(i);
	SendByte(dispBuffer[i][0]);
	SendByte(dispBuffer[i][1]);
	SendByte(dispBuffer[i][2]);
	SendByte(dispBuffer[i][3]);
	SendByte(dispBuffer[i][4]);
	LAT_BLK_SEND();
	i++;
}

void setBufferedData(uint8_t page,uint8_t block,uint8_t values){	//�򻺴��������
	dispBuffer[page][block] |= values;
}
void setBufferedIntData(uint8_t page,uint32_t values,uint8_t endValue){	//�򻺴��������
	uint8_t *p = (unsigned char *)&values;
	
	dispBuffer[page][4] |= endValue;
	dispBuffer[page][3] |= *p;
	dispBuffer[page][2] |= *++p;
	dispBuffer[page][1] |= *++p;
	dispBuffer[page][0] |= *++p;
}
void clearBufferedData(uint8_t page,uint8_t block){	//��ջ���
	dispBuffer[page][block] = 0x00;
}

void clearBufferedNum(position){	//��ջ���	
		
//		uint8_t *p3 = (unsigned char *)&Anode_NUM_MASK_1[2];
	if(position == 1){
		uint8_t *p = (unsigned char *)&Anode_NUM_MASK_1[2];
				dispBuffer[4][4] &= 0x00;
				dispBuffer[4][3] &= ~*p;
				dispBuffer[4][2] &= ~*++p;
				dispBuffer[4][1] &= ~*++p;
				dispBuffer[4][0] &= ~*++p;
	}else if(position ==2){
		uint8_t *p = (unsigned char *)&Anode_NUM_MASK_1[1];
				dispBuffer[4][4] &= 0x00;
				dispBuffer[4][3] &= ~*p;
				dispBuffer[4][2] &= ~*++p;
				dispBuffer[4][1] &= ~*++p;
				dispBuffer[4][0] &= ~*++p;				
	}else if(position ==3){
		uint8_t *p = (unsigned char *)&Anode_NUM_MASK_1[0];
				dispBuffer[4][4] &= 0x00;
				dispBuffer[4][3] &= ~*p;
				dispBuffer[4][2] &= ~*++p;
				dispBuffer[4][1] &= ~*++p;
				dispBuffer[4][0] &= ~*++p;				
	}else if(position ==4){
		uint8_t *p = (unsigned char *)&Anode_NUM_MASK_2[2];
				dispBuffer[5][4] &= 0x00;
				dispBuffer[5][3] &= ~*p;
				dispBuffer[5][2] &= ~*++p;
				dispBuffer[5][1] &= ~*++p;
				dispBuffer[5][0] &= ~*++p;				
	}else if(position ==5){
		uint8_t *p = (unsigned char *)&Anode_NUM_MASK_2[1];
				dispBuffer[5][4] &= 0x00;
				dispBuffer[5][3] &= ~*p;
				dispBuffer[5][2] &= ~*++p;
				dispBuffer[5][1] &= ~*++p;
				dispBuffer[5][0] &= ~*++p;				
	}else if(position ==6){
		uint8_t *p = (unsigned char *)&Anode_NUM_MASK_2[0];
				dispBuffer[5][4] &= 0x00;
				dispBuffer[5][3] &= ~*p;
				dispBuffer[5][2] &= ~*++p;
				dispBuffer[5][1] &= ~*++p;
				dispBuffer[5][0] &= ~*++p;				
	}else if(position ==7){
		uint8_t *p = (unsigned char *)&Anode_NUM_MASK_3[2];
				dispBuffer[6][4] &= 0x00;
				dispBuffer[6][3] &= ~*p;
				dispBuffer[6][2] &= ~*++p;
				dispBuffer[6][1] &= ~*++p;
				dispBuffer[6][0] &= ~*++p;				
	}
	
//		switch(position) //GRID �л�
//		{
//			case 1:
//				dispBuffer[4][4] &= 0x00;
//				dispBuffer[4][3] &= ~*p3;
//				dispBuffer[4][2] &= ~*++p3;
//				dispBuffer[4][1] &= ~*++p3;
//				dispBuffer[4][0] &= ~*++p3;
//					break;
//			
//			case 2:
//					break;
//			case 3:
//					break;
//			case 4:
//					break;
//			case 5:
//					break;
//			case 6:
//					break;
//			case 7:
//					break;
//		}
}



//void AnodeNumSelect(uint8_t position,uint8_t values){
//	
//	
//	
//}

//void send57(unsigned char t,unsigned char n)  //��ʾ57���� ʹ��anode2 ��ģ
//{
//	SendByte(0x00) ;
//	SendByte(0x00) ;
//	SendByte(0x00) ;
//	SendByte(0x00) ;
//	SendByte(0x00) ;
//      gridSelect(t);


//	SendByte(Anode_2[(n)][0]) ; //a-e
//	SendByte(Anode_2[(n)][1]) ; //d-com
//	SendByte(Anode_2[(n)][2]) ; //d-com
//	SendByte(Anode_2[(n)][3]) ; //d-com
//	SendByte(Anode_2[(n)][4]|dislogo[t]) ; //d-com


//    LAT_BLK_SEND();
//} 

void sendnum(unsigned char t,unsigned char n)	  //��ʾ���� ʹ��anode3��ģ
{
	SkipSend() ;
	gridSelect(t);
	SendByte(Anode_3[(n)][0]) ; //a-e
	SendByte(Anode_3[(n)][1]) ; //d-com
	SendByte(Anode_3[(n)][2]) ; //d-com
	SendByte(Anode_3[(n)][3]) ; //d-com
	SendByte(Anode_3[(n)][4]) ; //d-com

    LAT_BLK_SEND();

}

//void send57ab(unsigned char t,unsigned char n,unsigned char m)	  //8-10G	10 UP 57+DOWN 57
//{
//  	grid_send2(t);
//	SendByte(Anode_b[(m)][0]) ; //a-e
//	SendByte(Anode_b[(m)][1]) ; //a-e
//	SendByte(Anode_b[(m)][2]) ; //a-e
//	SendByte(Anode_b[(m)][3]) ; //a-e
//	SendByte(Anode_b[(m)][4]) ; //a-e
//	SendByte(Anode_b[(m)][5]) ; //a-e

//	SendByte(Anode_a[(n)][0]) ; //a-e
//	SendByte(Anode_a[(n)][1]) ; //a-e
//	SendByte(Anode_a[(n)][2]) ; //a-e
//	SendByte(Anode_a[(n)][3]) ; //a-e
//	SendByte(Anode_a[(n)][4]) ; //a-e
//	SendByte(0x00) ;
//	LAT_BLK_SEND();

//}


//void Test1()
//{

//send57(1,1);
//send57(2,2);
//send57(3,1);
//send57(4,1);

//sendnum(5,1);
//sendnum(6,1);
//sendnum(7,1);

//send57(8,1);
//send57(9,2);
//send57(10,2); 
////	SendByte(0xff) ;
////	SendByte(0xff) ;
////	SendByte(0xff) ;
////	SendByte(0xff) ;
////	SendByte(0xff) ;

////dislogo[4]=0x02;
////dislogo[8]=0x02;
////dislogo[9]=0x02;
////dislogo[10]=0x02;
//}

void Test3(){

setBufferedData(5,0,0x0F);
setBufferedData(5,1,0x83);
setBufferedData(5,2,0xA8);
setBufferedData(5,3,0x98);
setBufferedData(5,4,0x00);	

}

void DispNum(uint8_t position , uint8_t value){	//λ�ã����� ֻ�����ֶ���λ����ʾ
	
	switch(position) //GRID �л�
		{
			case 1:
				clearBufferedNum(1);
				setBufferedIntData(4,Anode_NUMS[value],0x00);	break;
			case 2:
				clearBufferedNum(2);
				setBufferedIntData(4,Anode_NUMS[value]<<1,0x00);	break;
			case 3:
				clearBufferedNum(3);
				setBufferedIntData(4,Anode_NUMS[value]<<2,0x00);	break;
			case 4:
				clearBufferedNum(4);
				setBufferedIntData(5,Anode_NUMS[value],0x00);	break;
			case 5:
				clearBufferedNum(5);
				setBufferedIntData(5,Anode_NUMS[value]<<1,0x00);	break;
			case 6:
				clearBufferedNum(6);
				setBufferedIntData(5,Anode_NUMS[value]<<2,0x00);	break;
			case 7:
				clearBufferedNum(7);
				setBufferedIntData(6,Anode_NUMS[value],0x00);	break;
		}

}


 